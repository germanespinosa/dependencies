def install_dependency(module_file):
    filename = module_file.split("/")[-1].replace(".zip", "")
    build = int(filename.split(".")[-1])
    minor = int(filename.split(".")[-2])
    major = int(filename.split(".")[-3])
    required_version = (major, minor, build)
    module_name = filename.split(".")[0]
    print(module_name, required_version)
    module_version = getattr(__import__(module_name, fromlist=["module_version"]), "module_version")
    print(module_version())
    if required_version != module_version():
        if module_file.startswith("https://"):
            module_file = download_module(module_file)
            destination = get_user_modules_folder()
            extract_module(module_file, destination)


def download_module(uri):
    import requests
    import tempfile
    try:
        content = requests.get(uri).content
        with tempfile.TemporaryFile(delete=False) as file:
            file.write(content)
            return file.name
    except:
        print("error downloading file")
        exit(1)


def extract_module(file_name, destination):
    import zipfile
    with zipfile.ZipFile(file_name, 'r') as zip_ref:
        zip_ref.extractall(destination)


def get_user_modules_folder():
    import subprocess
    return subprocess.Popen(["python", "-m", "site", "--user-site"], stdout=subprocess.PIPE).communicate()[0].decode().replace("\n", "").replace("\r", "")


def get_version_from_string(version_string):
    major = int(version_string.split(".")[0])
    minor = int(version_string.split(".")[1])
    build = int(version_string.split(".")[2])
    return major, minor, build


def get_current_version(module_name):
    import os
    if os.path.exists(module_name + "/__version__.py"):
        sys.path.insert(1, module_name)
        from __version__ import module_version
        return module_version()
    else:
        return 0, 0, 0


def get_version_string(major, minor, build):
    return str(major) + "." + str(minor) + "." + '{:0>3}'.format(build)


def get_version_script(major, minor, build):
    version_script = "def module_version():\n"
    version_script += "\treturn " + str(major) + ", " + str(minor) + ", " + str(build) + " \n"
    return version_script


def save_version_script(module_name, major, minor, build):
    script = get_version_script(major, minor, build)
    with open(module_name + "/__version__.py", "w") as v:
        v.write(script)


def build_module(module_name, module_file):
    from zipfile import ZipFile
    from glob import glob
    zipObj = ZipFile(module_file, 'w')
    g = glob(module_name + "/*")
    for f in g:
        zipObj.write(f)
    zipObj.close()

