def __module_version__():
	return 1, 0, 0 
